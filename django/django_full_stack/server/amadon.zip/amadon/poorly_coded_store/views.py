from django.shortcuts import render, redirect
from .models import Order, Product


def index(request):
    return render(request, "store/index.html", {"all_products": Product.objects.all()})


def handling_payment(request):
    quantity_from_form = int(request.POST["quantity"])
    price_from_form = float(request.POST["price"])
    total_charge = quantity_from_form * price_from_form
    order = Order.objects.create(quantity_ordered=quantity_from_form,
                                 total_price=total_charge)
    return redirect(f"/checkout/{order.id}")


def checkout(request, id):
    orders = Order.objects.all()

    total_price = 0
    for order in orders:
        total_price += order.total_price

    return render(request, "store/checkout.html", {'orders': orders, 'your_order': orders.get(id=id), 'total_price': total_price})
